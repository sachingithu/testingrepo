package com.marlabs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtSampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
