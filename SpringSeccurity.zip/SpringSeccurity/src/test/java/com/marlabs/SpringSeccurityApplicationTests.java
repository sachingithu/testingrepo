package com.marlabs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSeccurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
