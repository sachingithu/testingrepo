package com.marlabs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSeccurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSeccurityApplication.class, args);
	}

}
